local mapScale = 1.5  -- Change this to whatever you like

local scaler = CreateFrame("Frame", nil, UIParent)
scaler:RegisterEvent("WORLD_MAP_UPDATE")
scaler:SetScript("OnEvent", function(self, event, unit, ...)
    WorldMapFrame:SetScale(mapScale)
end)